import 'package:flutter/material.dart';

class WelcomeScreen extends StatelessWidget {
  final void Function() goToLogicScreen;
  const WelcomeScreen({super.key, required this.goToLogicScreen});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text("Welcome"),
          TextButton(onPressed: goToLogicScreen, child: Text("Click")),
        ],
      ),
    );
  }
}
