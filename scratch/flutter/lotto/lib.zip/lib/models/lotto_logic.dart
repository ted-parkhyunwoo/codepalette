import 'dart:math';

final Random random = Random();

class LottoLogic {
  List<int> nums = [];
  List<int> res = [];

  // init
  LottoLogic() {
    init();
  }

  void init() {
    nums.clear();
    res.clear();
    for (int i = 1; i <= 45; ++i) {
      nums.add(i);
    }
  }

  List<int> get randomSixDigits {
    init();

    int allIdx = 45;
    for (int i = 0; i < 6; ++i) {
      int bfIdx = random.nextInt(allIdx--);
      res.add(nums[bfIdx]);
      nums.removeAt(bfIdx);
    }

    res.sort();
    return res;
  }
}

void main(List<String> args) {
  LottoLogic lottoLogic = LottoLogic();
  for (int i = 0; i < 5; ++i) {
    print(lottoLogic.randomSixDigits);
  }
}
